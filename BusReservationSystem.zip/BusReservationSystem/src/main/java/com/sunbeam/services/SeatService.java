package com.sunbeam.services;

import com.sunbeam.entities.Seat;

public interface SeatService {
	Seat saveSeat(Seat seat);
}
